To graphically design your analysis data-set:

- From the Dashboards menu, select "Custom BI Views"
- BI Views creation is restricted to members of "BI View Editor Manager"
  group. You can add this group to a user in User form, Access Rights,
  Technical section.
- Browse trough the business objects in the "Query Builder" tab
- Pick the interesting fields (Drag & Drop)
- For each selected field, right-click on the Options column and select
  whether it's a row, column or measure; if you want to remove the field
  from the list view, unflag the checkbox ´List´ in the Options column
- Save and click "Generate BI View"
- Click "Open BI View" to view the result

To access the created BI View with a dedicated menu:

- If module Dashboard (board) is installed, the standard "Add to My
  Dashboard" functionality would be available
- "Create a menu" is restricted to members of "BI View Editor Manager"
  group.
- Click "Create a menu" to create a new menu item directly linked to
  your new BI view (this feature is available in developer mode); when
  the BI view is reset back to draft this menu will be removed, and you
  will need to re-create the menu entry.

A more advanced UI is also available under the "Details" tab. It
provides extra possibilities for more advanced users, like to use LEFT
JOIN instead of the default INNER JOIN.

It also possible to improve the IDs generation for new views by adding
an Over Condition in the "SQL" tab, see
<https://www.postgresql.org/docs/current/sql-expressions.html#SYNTAX-WINDOW-FUNCTIONS>
for further details. For instance, an ORDER BY clause helps preventing
unreliable behavior when filtering the generated views.
